package org.asdtiang.grails.paginate

class TestAjax {
	String name
}
